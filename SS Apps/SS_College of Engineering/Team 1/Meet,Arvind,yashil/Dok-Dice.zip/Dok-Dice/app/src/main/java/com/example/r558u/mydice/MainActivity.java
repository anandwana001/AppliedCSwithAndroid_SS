package com.example.r558u.mydice;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView cpu,player;
    TextView cpu1,player1,vs;
    int cpuPoints,playerPoints;
     Random r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cpu=(ImageView)findViewById(R.id.cpu);
        player=(ImageView)findViewById(R.id.player);
        cpu1=(TextView)findViewById(R.id.cpu1);
        player1=(TextView)findViewById(R.id.player1);
        r=new Random();
        player.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int cpuThrow=r.nextInt(6)+1;
                int playerThrow=r.nextInt(6)+1;
                setImageCpu(cpuThrow);
                setImagePlayer(playerThrow);
                if(cpuThrow>playerThrow)
                {
                    cpuPoints++;

                }
                if(playerThrow>cpuThrow)
                {
                    playerPoints++;

                }
                if (playerPoints>cpuPoints)
                {
                    cpuPoints++;
                }
                if(playerPoints>100)
                {
                    player1.setText("you win:");
                }
                else
                {
                    cpu1.setText("you lose");
                }

                cpu1.setText("Computer score:"+cpuPoints);
                player1.setText("Your score:"+playerPoints);

                Animation rotate= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
                cpu.startAnimation(rotate);
                player.startAnimation(rotate);

            }
        });
    }
    public void setImageCpu(int num) {
        switch (num) {
            case 1:
                cpu.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                cpu.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                cpu.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                cpu.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                cpu.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                cpu.setImageResource(R.drawable.dice_6);
                break;
        }
    }
    public void setImagePlayer(int num){
        switch (num){
            case 1:
                player.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                player.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                player.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                player.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                player.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                player.setImageResource(R.drawable.dice_6);
                break;
        }

    }
}
